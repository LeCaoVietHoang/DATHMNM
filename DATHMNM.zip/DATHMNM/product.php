<?php
// product.php - Chi tiết sản phẩm
session_start();

require_once 'core/database.php';
require_once 'models/ProductModel.php';

$product_id = $_GET['id'] ?? null;

if (!$product_id) {
    header('Location: index.php');
    exit;
}

$productModel = new ProductModel($pdo);
$product = $productModel->getProductDetails($product_id);

if (!$product || $product['TrangThai'] !== 'active') {
    header('Location: index.php');
    exit;
}

// Get related products
$related_products = $productModel->getActiveProducts($product['MaDanhMuc']);
$related_products = array_filter($related_products, function($p) use ($product_id) {
    return $p['MaSanPham'] != $product_id;
});
$related_products = array_slice($related_products, 0, 4);

// Increment view count
$productModel->incrementViewCount($product_id);

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['TenSanPham']); ?> - Chi tiết sản phẩm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .product-gallery img {
            cursor: pointer;
            transition: transform 0.3s;
        }
        .product-gallery img:hover {
            transform: scale(1.05);
        }
        .product-price {
            color: #dc3545;
            font-weight: bold;
            font-size: 1.8rem;
        }
        .product-old-price {
            text-decoration: line-through;
            color: #6c757d;
            font-size: 1.2rem;
        }
        .product-discount {
            background: #dc3545;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.9rem;
        }
        .quantity-input {
            width: 80px;
            text-align: center;
        }
        .related-product-card {
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .related-product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .product-meta {
            font-size: 0.9rem;
            color: #666;
        }
        .product-description img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">Trang chủ</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php">
                            <i class="fas fa-shopping-cart"></i> Giỏ hàng
                            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                                <span class="badge bg-danger"><?php echo count($_SESSION['cart']); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container py-5">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Trang chủ</a></li>
                <li class="breadcrumb-item"><a href="category.php?id=<?php echo $product['MaDanhMuc']; ?>"><?php echo htmlspecialchars($product['TenDanhMuc'] ?? 'Danh mục'); ?></a></li>
                <li class="breadcrumb-item active"><?php echo htmlspecialchars($product['TenSanPham']); ?></li>
            </ol>
        </nav>

        <!-- Product Detail -->
        <div class="row">
            <!-- Product Images -->
            <div class="col-lg-6">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <?php if(!empty($product['URLAnhChinh'])): ?>
                            <!-- START: ĐÃ SỬA LỖI ĐƯỜNG DẪN ẢNH CHÍNH (URLAnhChinh) -->
                            <img src="<?php echo htmlspecialchars($product['URLAnhChinh']); ?>" 
                                 alt="<?php echo htmlspecialchars($product['TenSanPham']); ?>" 
                                 class="img-fluid rounded" 
                                 id="main-product-image">
                            <!-- END: ĐÃ SỬA LỖI ĐƯỜNG DẪN ẢNH CHÍNH (URLAnhChinh) -->
                        <?php else: ?>
                            <img src="assets/images/no-image.jpg" 
                                 alt="No image" 
                                 class="img-fluid rounded">
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Thumbnail Gallery -->
                <?php if(!empty($product['URLAnhChinh'])): ?>
                <div class="row product-gallery">
                    <div class="col-3">
                        <!-- START: ĐÃ SỬA LỖI ĐƯỜNG DẪN ẢNH THUMBNAIL (URLAnhChinh) -->
                        <img src="<?php echo htmlspecialchars($product['URLAnhChinh']); ?>" 
                             class="img-thumbnail" 
                             onclick="changeMainImage(this.src)">
                        <!-- END: ĐÃ SỬA LỖI ĐƯỜNG DẪN ẢNH THUMBNAIL (URLAnhChinh) -->
                    </div>
                    <!-- Thêm các ảnh thumbnail khác ở đây nếu có -->
                </div>
                <?php endif; ?>
            </div>

            <!-- Product Info -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h1 class="h2"><?php echo htmlspecialchars($product['TenSanPham']); ?></h1>
                        
                        <div class="d-flex align-items-center mb-3">
                            <span class="product-price">
                                <?php echo number_format($product['GiaBan'], 0, ',', '.'); ?> ₫
                            </span>
                            <?php if($product['GiaBan'] > $product['GiaBan']): ?>
                                <span class="product-old-price ms-3">
                                    <?php echo number_format($product['GiaGoc'], 0, ',', '.'); ?> ₫
                                </span>
                                <span class="product-discount ms-2">
                                    -<?php echo number_format((($product['GiaGoc'] - $product['GiaBan']) / $product['GiaGoc']) * 100, 0); ?>%
                                </span>
                            <?php endif; ?>
                        </div>

                        <!-- Product Meta -->
                        <div class="product-meta mb-4">
                            <div class="mb-2">
                                <i class="fas fa-eye me-1"></i>
                                <span><?php echo number_format($product['LuotXem']); ?> lượt xem</span>
                            </div>
                            <div class="mb-2">
                                <i class="fas fa-box me-1"></i>
                                <span>Mã SP: <?php echo htmlspecialchars($product['MaSanPham']); ?></span>
                            </div>
                            <?php if($product['TonKho'] > 0): ?>
                                <div class="text-success">
                                    <i class="fas fa-check-circle me-1"></i>
                                    <span>Còn hàng (<?php echo $product['TonKho']; ?> sản phẩm)</span>
                                </div>
                            <?php else: ?>
                                <div class="text-danger">
                                    <i class="fas fa-times-circle me-1"></i>
                                    <span>Tạm hết hàng</span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Product Description Short -->
                        <div class="mb-4">
                            <h5 class="mb-2">Mô tả ngắn:</h5>
                            <p><?php echo nl2br(htmlspecialchars($product['MoTa'])); ?></p>
                        </div>

                        <!-- Add to Cart -->
                        <?php if($product['TonKho'] > 0): ?>
                        <form action="cart.php?action=add" method="POST" class="mb-4">
                            <input type="hidden" name="product_id" value="<?php echo $product['MaSanPham']; ?>">
                            <input type="hidden" name="product_name" value="<?php echo htmlspecialchars($product['TenSanPham']); ?>">
                            <input type="hidden" name="product_price" value="<?php echo $product['GiaBan']; ?>">
                            <!-- Sử dụng đường dẫn ảnh trực tiếp -->
                            <input type="hidden" name="product_image" value="<?php echo htmlspecialchars($product['URLAnhChinh']); ?>">
                            
                            <div class="row g-3 align-items-center mb-3">
                                <div class="col-auto">
                                    <label class="form-label">Số lượng:</label>
                                </div>
                                <div class="col-auto">
                                    <div class="input-group">
                                        <button type="button" class="btn btn-outline-secondary" onclick="decreaseQuantity()">-</button>
                                        <input type="number" 
                                                name="quantity" 
                                                id="quantity" 
                                                class="form-control quantity-input" 
                                                value="1" 
                                                min="1" 
                                                max="<?php echo $product['TonKho']; ?>">
                                        <button type="button" class="btn btn-outline-secondary" onclick="increaseQuantity()">+</button>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <span class="text-muted">Tối đa: <?php echo $product['TonKho']; ?> sản phẩm</span>
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex">
                                <button type="submit" class="btn btn-danger btn-lg flex-fill">
                                    <i class="fas fa-cart-plus me-2"></i>Thêm vào giỏ hàng
                                </button>
                                <button type="button" class="btn btn-outline-primary btn-lg flex-fill">
                                    <i class="fas fa-credit-card me-2"></i>Mua ngay
                                </button>
                            </div>
                        </form>
                        <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Sản phẩm đang tạm hết hàng. Vui lòng quay lại sau!
                        </div>
                        <?php endif; ?>

                        <!-- Social Sharing -->
                        <div class="border-top pt-3 mt-3">
                            <h6 class="mb-2">Chia sẻ:</h6>
                            <div class="d-flex gap-2">
                                <a href="#" class="btn btn-outline-primary btn-sm">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="#" class="btn btn-outline-info btn-sm">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a href="#" class="btn btn-outline-danger btn-sm">
                                    <i class="fab fa-pinterest"></i>
                                </a>
                                <a href="#" class="btn btn-outline-success btn-sm">
                                    <i class="fab fa-whatsapp"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Product Tabs -->
        <div class="row mt-5">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs" id="productTabs">
                            <li class="nav-item">
                                <a class="nav-link active" data-bs-toggle="tab" href="#description">Mô tả chi tiết</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#specifications">Thông số kỹ thuật</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#reviews">Đánh giá</a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                            <!-- Description Tab -->
                            <div class="tab-pane fade show active" id="description">
                                <div class="product-description">
                                    <?php echo !empty($product['MoTaChiTiet']) ? $product['MoTaChiTiet'] : 'Đang cập nhật...'; ?>
                                </div>
                            </div>
                            
                            <!-- Specifications Tab -->
                            <div class="tab-pane fade" id="specifications">
                                <?php if(!empty($product['ThongSoKyThuat'])): ?>
                                    <?php echo $product['ThongSoKyThuat']; ?>
                                <?php else: ?>
                                    <p class="text-muted">Đang cập nhật thông tin...</p>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Reviews Tab -->
                            <div class="tab-pane fade" id="reviews">
                                <div class="text-center py-4">
                                    <i class="fas fa-comments fa-3x text-muted mb-3"></i>
                                    <h5>Chưa có đánh giá nào</h5>
                                    <p class="text-muted">Hãy là người đầu tiên đánh giá sản phẩm này!</p>
                                    <button class="btn btn-primary">Viết đánh giá</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Products -->
        <?php if(!empty($related_products)): ?>
        <div class="row mt-5">
            <div class="col-12">
                <h3 class="mb-4">Sản phẩm liên quan</h3>
                <div class="row">
                    <?php foreach($related_products as $related): ?>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card related-product-card h-100">
                            <a href="product.php?id=<?php echo $related['MaSanPham']; ?>">
                                <?php if(!empty($related['URLAnhChinh'])): ?>
                                    <!-- START: ĐÃ SỬA LỖI ĐƯỜNG DẪN ẢNH SẢN PHẨM LIÊN QUAN (URLAnhChinh) -->
                                    <img src="<?php echo htmlspecialchars($related['URLAnhChinh']); ?>" 
                                         class="card-img-top" 
                                         alt="<?php echo htmlspecialchars($related['TenSanPham']); ?>">
                                    <!-- END: ĐÃ SỬA LỖI ĐƯỜNG DẪN ẢNH SẢN PHẨM LIÊN QUAN (URLAnhChinh) -->
                                <?php else: ?>
                                    <img src="assets/images/no-image.jpg" 
                                         class="card-img-top" 
                                         alt="No image">
                                <?php endif; ?>
                            </a>
                            <div class="card-body">
                                <h5 class="card-title">
                                    <a href="product.php?id=<?php echo $related['MaSanPham']; ?>" class="text-decoration-none text-dark">
                                        <?php echo htmlspecialchars(mb_substr($related['TenSanPham'], 0, 50) . (mb_strlen($related['TenSanPham']) > 50 ? '...' : '')); ?>
                                    </a>
                                </h5>
                                <p class="card-text text-danger fw-bold">
                                    <?php echo number_format($related['GiaBan'], 0, ',', '.'); ?> ₫
                                    <?php if($related['GiaGoc'] > $related['GiaBan']): ?>
                                        <small class="text-muted text-decoration-line-through ms-2">
                                            <?php echo number_format($related['GiaGoc'], 0, ',', '.'); ?> ₫
                                        </small>
                                    <?php endif; ?>
                                </p>
                            </div>
                            <div class="card-footer bg-transparent">
                                <a href="product.php?id=<?php echo $related['MaSanPham']; ?>" class="btn btn-outline-primary btn-sm w-100">
                                    Xem chi tiết
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="bg-light mt-5 py-4 border-top">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Về chúng tôi</h5>
                    <p>Cửa hàng uy tín, chất lượng</p>
                </div>
                <div class="col-md-4">
                    <h5>Liên hệ</h5>
                    <p>Email: contact@example.com</p>
                    <p>Điện thoại: 0123 456 789</p>
                </div>
                <div class="col-md-4">
                    <h5>Theo dõi</h5>
                    <div class="d-flex gap-2">
                        <a href="#" class="text-dark"><i class="fab fa-facebook fa-2x"></i></a>
                        <a href="#" class="text-dark"><i class="fab fa-twitter fa-2x"></i></a>
                        <a href="#" class="text-dark"><i class="fab fa-instagram fa-2x"></i></a>
                    </div>
                </div>
            </div>
            <div class="text-center mt-3">
                <p class="mb-0">© 2023 Cửa hàng. Tất cả các quyền được bảo lưu.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Change main product image
        function changeMainImage(src) {
            document.getElementById('main-product-image').src = src;
        }

        // Quantity controls
        function increaseQuantity() {
            const input = document.getElementById('quantity');
            const max = parseInt(input.max);
            if (parseInt(input.value) < max) {
                input.value = parseInt(input.value) + 1;
            }
        }

        function decreaseQuantity() {
            const input = document.getElementById('quantity');
            if (parseInt(input.value) > 1) {
                input.value = parseInt(input.value) - 1;
            }
        }

        // Product tabs
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize tabs
            const triggerTabList = document.querySelectorAll('#productTabs a');
            triggerTabList.forEach(function(triggerEl) {
                const tabTrigger = new bootstrap.Tab(triggerEl);
                triggerEl.addEventListener('click', function(event) {
                    event.preventDefault();
                    tabTrigger.show();
                });
            });

            // Quantity input validation
            const quantityInput = document.getElementById('quantity');
            if (quantityInput) {
                quantityInput.addEventListener('change', function() {
                    const max = parseInt(this.max);
                    const min = parseInt(this.min);
                    let value = parseInt(this.value);
                    
                    if (value > max) this.value = max;
                    if (value < min) this.value = min;
                    if (isNaN(value)) this.value = 1;
                });
            }
        });
    </script>
</body>
</html>