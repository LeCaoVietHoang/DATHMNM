<?php
// Bắt đầu session
session_start();

// Thiết lập page title mặc định
$pageTitle = $pageTitle ?? 'Gundam Store';

// Kiểm tra trạng thái đăng nhập
$isLoggedIn = isset($_SESSION['user_id']);
$userName = $_SESSION['user_name'] ?? '';
$userRole = $_SESSION['user_role'] ?? '';
$userAvatar = $_SESSION['user_avatar'] ?? 'default-avatar.jpg';

// Đếm số lượng trong giỏ hàng
$cartCount = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += $item['quantity'] ?? 1;
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo htmlspecialchars($pageTitle); ?></title> 

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="./core/public/assets/css/style.css">
    
    <style>
        /* Header Custom Styles */
        .navbar-brand {
            font-weight: bold;
            font-size: 1.8rem;
            color: #ffd700 !important;
        }
        
        .nav-link {
            color: #e0e0e0 !important;
            transition: color 0.3s;
        }
        
        .nav-link:hover {
            color: #ffd700 !important;
        }
        
        .cart-icon {
            position: relative;
            color: #e0e0e0;
            text-decoration: none;
        }
        
        .cart-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #dc3545;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #ffd700;
        }
        
        .dropdown-menu {
            background-color: #343a40;
            border: 1px solid #495057;
        }
        
        .dropdown-item {
            color: #e0e0e0;
        }
        
        .dropdown-item:hover {
            background-color: #495057;
            color: #ffd700;
        }
        
        .dropdown-divider {
            border-color: #495057;
        }
        
        .auth-buttons .btn {
            padding: 0.375rem 1rem;
        }
        
        /* Badge cho admin */
        .admin-badge {
            background: linear-gradient(45deg, #ff6b6b, #ffd93d);
            color: #000;
            font-size: 0.7rem;
            padding: 2px 8px;
            border-radius: 10px;
            font-weight: bold;
            margin-left: 5px;
        }
        
        .welcome-text {
            color: #ffd700;
            font-weight: bold;
            margin-right: 10px;
        }
    </style>
</head>

<body class="bg-dark text-light">

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top border-bottom border-secondary">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand" href="index.php">
            <i class="fas fa-robot"></i> GUNDAM STORE
        </a>
        
        <!-- Mobile Toggle Button -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- Navbar Content -->
        <div class="collapse navbar-collapse" id="navbarContent">
            <!-- Navigation Links -->
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Trang chủ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="products.php"><i class="fas fa-robot"></i> Sản phẩm</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-layer-group"></i> Series
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="category.php?series=mg">MG - Master Grade</a></li>
                        <li><a class="dropdown-item" href="category.php?series=pg">PG - Perfect Grade</a></li>
                        <li><a class="dropdown-item" href="category.php?series=rg">RG - Real Grade</a></li>
                        <li><a class="dropdown-item" href="category.php?series=hg">HG - High Grade</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php"><i class="fas fa-info-circle"></i> Giới thiệu</a>
                </li>
            </ul>
            
            <!-- Right Side: Search, Cart, User -->
            <div class="d-flex align-items-center">
                <!-- Search Form -->
                <form class="d-flex me-3" action="search.php" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control bg-secondary border-secondary text-light" 
                               name="q" placeholder="Tìm Gundam..." style="width: 200px;">
                        <button class="btn btn-outline-warning" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
                
                <!-- Cart Icon -->
                <a href="cart.php" class="cart-icon me-3 position-relative">
                    <i class="fas fa-shopping-cart fa-lg"></i>
                    <?php if ($cartCount > 0): ?>
                        <span class="cart-count"><?php echo $cartCount; ?></span>
                    <?php endif; ?>
                </a>
                
                <!-- User Section (Thay đổi theo trạng thái đăng nhập) -->
                <div class="user-section">
                    <?php if ($isLoggedIn): ?>
                        <!-- Đã đăng nhập -->
                        <div class="dropdown">
                            <button class="btn btn-outline-light dropdown-toggle d-flex align-items-center" 
                                    type="button" data-bs-toggle="dropdown">
                                <img src="./core/public/assets/images/avatars/<?php echo $userAvatar; ?>" 
                                     alt="Avatar" class="user-avatar me-2">
                                <span class="me-1"><?php echo htmlspecialchars($userName); ?></span>
                                <?php if ($userRole === 'admin'): ?>
                                    <span class="admin-badge">ADMIN</span>
                                <?php endif; ?>
                            </button>
                            
                            <ul class="dropdown-menu dropdown-menu-end">
                                <!-- Nếu là admin -->
                                <?php if ($userRole === 'admin'): ?>
                                    <li>
                                        <a class="dropdown-item" href="admin/dashboard.php">
                                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard Admin
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="admin/products.php">
                                            <i class="fas fa-box me-2"></i>Quản lý sản phẩm
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="admin/orders.php">
                                            <i class="fas fa-clipboard-list me-2"></i>Quản lý đơn hàng
                                        </a>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                <?php endif; ?>
                                
                                <!-- Menu chung cho cả user và admin -->
                                <li>
                                    <a class="dropdown-item" href="profile.php">
                                        <i class="fas fa-user-circle me-2"></i>Hồ sơ cá nhân
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="orders.php">
                                        <i class="fas fa-history me-2"></i>Đơn hàng của tôi
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="wishlist.php">
                                        <i class="fas fa-heart me-2"></i>Yêu thích
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="logout.php">
                                        <i class="fas fa-sign-out-alt me-2"></i>Đăng xuất
                                    </a>
                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <!-- Chưa đăng nhập -->
                        <div class="auth-buttons">
                            <a href="register.php" class="btn btn-outline-primary me-2">
                                <i class="fas fa-user-plus me-1"></i>Đăng ký
                            </a>
                            <a href="login.php" class="btn btn-warning">
                                <i class="fas fa-sign-in-alt me-1"></i>Đăng nhập
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</nav>

<!-- Main Content -->
<main class="container-fluid p-0">