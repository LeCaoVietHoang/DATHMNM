<?php 
// Tên file: views/layout/footer.php
?>
<footer class="bg-black py-4 mt-5">
    <div class="container text-center">
        <p class="text-secondary">&copy; 2025 Gundam Store. All rights reserved.</p>
        <p class="text-warning">Liên hệ: support@gundamshop.vn</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>